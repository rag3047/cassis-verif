CBMC proof stubs
======================

This directory contains the stubs written for CBMC proofs.  It is
common to stub out functionality like network send and receive methods
when writing a CBMC proof, and the code for these stubs goes here.
