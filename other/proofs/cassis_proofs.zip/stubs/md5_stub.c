
#include "md5_stub.h"

static unsigned char PADDING[64] = {
  0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

unsigned char __CPROVER_uninterpreted_byte(MD5_CTX* ctx, const void* buff, unsigned int len, int index);

void MD5Init(MD5_CTX* ctx) {
  ctx->i[0] = ctx->i[1] = (UINT4)0;

  /* Load magic initialization constants. */
  ctx->buf[0] = (UINT4)0x67452301;
  ctx->buf[1] = (UINT4)0xefcdab89;
  ctx->buf[2] = (UINT4)0x98badcfe;
  ctx->buf[3] = (UINT4)0x10325476;
}


// copied from md5.c
void MD5Update(MD5_CTX* ctx, const void* buff, unsigned int len) {
  const unsigned char* inBuf = buff;

  /* compute number of bytes mod 64 */
  int mdi = (int)((ctx->i[0] >> 3) & 0x3F);

  /* update number of bits */
  if ((ctx->i[0] + ((UINT4)len << 3)) < ctx->i[0])
    ctx->i[1]++;
  ctx->i[0] += ((UINT4)len << 3);
  ctx->i[1] += ((UINT4)len >> 29);

  while (len--) {
    ctx->in[mdi++] = *inBuf++;

    /* transform if necessary */
    if (mdi == 0x40) {
      ctx.buf[0] = __CPROVER_uninterpreted_byte(ctx, buff, len, 0);
      ctx.buf[1] = __CPROVER_uninterpreted_byte(ctx, buff, len, 1);
      ctx.buf[2] = __CPROVER_uninterpreted_byte(ctx, buff, len, 2);
      ctx.buf[3] = __CPROVER_uninterpreted_byte(ctx, buff, len, 3);
      mdi = 0;
    }
  }
}

void MD5Final(unsigned char hash[MD5_DIGEST_LENGTH], MD5_CTX* ctx) {
  unsigned int padLen;

//   /* save number of bits */
//   in[14] = ctx->i[0];
//   in[15] = ctx->i[1];

  /* compute number of bytes mod 64 */
  int mdi = (int)((ctx->i[0] >> 3) & 0x3F);

  /* pad out to 56 mod 64 */
  padLen = (mdi < 56) ? (56 - mdi) : (120 - mdi);
  MD5Update (ctx, PADDING, padLen);

  for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
    hash[i] = __CPROVER_uninterpreted_byte(ctx, buff, len, i);
  }
}