#include "compose_science_header_stub.h"
#include "cassis_compile_options.h"

unsigned char compose_science_header(unsigned char *header, struct imem_exposure_alloc_t *desc, uint32_t image_length) {
    unsigned char l = 0;
	l += 5;
	l += 5;
	l += 8;
	l += 5;
	l += 4;
	l += 5;
	l++;
	l += 5;
	l++;
	l += 5;
	l += 1;
	l += 5;
	l += 4;
	l += 5;
	l += 4;
	l += 5;
	l++;
	l += 5;
	l += 4;
	l += 5;
	l += 4;
	l += 5;
	l += 8;

	// if window cnt == 0 -> PE science HK (64 bytes) is at the beginning of the allocated memory area
#ifndef INCLUDE_PE_HK_ALL
	if (desc->window_cnt == 0)
	{
#endif
		l += 5;
		l += 64;
#ifndef INCLUDE_PE_HK_ALL
	}
#endif
	l++;
	l += 4;

	return l;
}