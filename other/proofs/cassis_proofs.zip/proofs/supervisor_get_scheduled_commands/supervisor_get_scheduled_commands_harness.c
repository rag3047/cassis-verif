// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

/*
 * Insert copyright notice
 */

/**
 * @file supervisor_get_scheduled_commands_harness.c
 * @brief Implements the proof harness for supervisor_get_scheduled_commands function.
 */

/*
 * Insert project header files that
 *   - include the declaration of the function
 *   - include the types needed to declare function arguments
 */

#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "cassis_supervisor_internal.h"
#include "cassis_cmdscript_interpreter.h"

// Note: Modify cassis_cmdscript_interpreter.h: set CMDTAB_MAX_ATOMIC_COMMANDS to 10, to make sure the proof finishes faster

// since we don't have a header file, we just add a forward definition.
void supervisor_get_scheduled_commands(uint64_t scheduleTS, struct gds_atomic_command_t **ts_command, int *ts_cnt, struct gds_atomic_command_t **command, int *cnt);

// generate nondet uint64
uint64_t nondet_uint64();
// // holds a preissue timestamp for every command, allows mapping command ptr to preissue timestamp
uint64_t preissue_ts_lookup_table[CMDTAB_MAX_ATOMIC_COMMANDS];

/*
  Initialize command_table and nondet choose number of pending commands.
  Also count number of pending and zero-timestamp commands.
*/
void command_table_init(uint64_t scheduleTS, uint32_t* num_ts_zero, uint32_t* num_pending, uint32_t* num_preissue) {
  __CPROVER_havoc_object(&command_table);

  uint32_t _ts_zero = 0;
  uint32_t _pending = 0;
  uint32_t _preissue = 0;

  for (int i = 0; i < CMDTAB_MAX_ATOMIC_COMMANDS; i++) {
    // count number of entries generated
    if (command_table.commands[i].status == CMDTAB_COMMAND_STATUS_PENDING) {
      _pending++;

      if (command_table.commands[i].timestamp == 0) {
        _ts_zero++;
      } else {
        // populate lookup table with preissue timestamps
        preissue_ts_lookup_table[i] = nondet_uint64();
        __CPROVER_assume(preissue_ts_lookup_table[i] > 0 && preissue_ts_lookup_table[i] <= command_table.commands[i].timestamp);

        if (preissue_ts_lookup_table[i] < scheduleTS) {
          _preissue++;
        }
      }
    }
  }

  *num_pending = _pending;
  *num_ts_zero = _ts_zero;
  *num_preissue = _preissue;
}

uint64_t get_preissue_timestamp(struct gds_atomic_command_t *command) {
  if (command == NULL) return 0;

  struct gds_atomic_command_t *base_ptr = (struct gds_atomic_command_t *) &command_table.commands;
  uint64_t index = command - base_ptr;
  
  assert(index >= 0 && index < CMDTAB_MAX_ATOMIC_COMMANDS);
  return preissue_ts_lookup_table[index];
}

/**
 * @brief Starting point for formal analysis
 * 
 */
void harness(void)
{

  /* Insert argument declarations */

  #if CMDTAB_MAX_ATOMIC_COMMANDS > 10
  
  // mark proof as failed and early exit if CMDTAB_MAX_ATOMIC_COMMANDS is too large,
  // because it will cause the proof to run for several days
  assert(false);
  return;

  #endif /* CMDTAB_MAX_ATOMIC_COMMANDS > 10 */

  uint32_t num_pending = 0;
  uint32_t num_ts_zero = 0;
  uint32_t num_preissue = 0;

  uint64_t scheduleTS;
  int ts_cnt;
  int cnt;

  // initialize command_table
  command_table_init(scheduleTS, &num_ts_zero, &num_pending, &num_preissue);

  supervisor_get_scheduled_commands(scheduleTS, scheduled_ts_commands, &ts_cnt, scheduled_commands, &cnt);

  // check that the returned counts correspond to what was nondet initialized by cbmc
  assert(cnt == num_ts_zero);
  assert(ts_cnt >= 0 && ts_cnt <= num_pending - num_ts_zero);
  assert(ts_cnt == num_preissue);
  assert(ts_cnt + cnt <= num_pending);

  // check that every pointer in scheduled_commands and scheduled_ts_commands corresponds to a command in the command_table.commands array
  int ts_zero_index = 0;
  int preissue_index = 0;

  for (int i = 0; i < CMDTAB_MAX_ATOMIC_COMMANDS; i++) {
    if (command_table.commands[i].status == CMDTAB_COMMAND_STATUS_PENDING) {
      if (command_table.commands[i].timestamp == 0) {
        assert(__CPROVER_same_object(&command_table.commands[i], &scheduled_commands[ts_zero_index]));
        ts_zero_index++;
      } else if (get_preissue_timestamp(&command_table.commands[i]) < scheduleTS) {
        assert(__CPROVER_same_object(&command_table.commands[i], &scheduled_ts_commands[preissue_index]));
        preissue_index++;
      }
    }
  }

  // check that nothing was missed when comparing pointers
  assert(ts_zero_index == cnt);
  assert(preissue_index == ts_cnt);
}
