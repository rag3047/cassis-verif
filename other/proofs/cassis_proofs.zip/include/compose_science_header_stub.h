#include <stdint.h>
#include "cassis_image_memory.h"

unsigned char compose_science_header(unsigned char *header, struct imem_exposure_alloc_t *desc, uint32_t image_length);
