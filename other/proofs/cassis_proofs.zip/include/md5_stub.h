
#include <md5.h>

void MD5Init(MD5_CTX*);
void MD5Update(MD5_CTX*, const void*, unsigned int);
void MD5Final(unsigned char[16], MD5_CTX*);
